! ***********************************************************************
!
!   Copyright (C) 2012-2019  Bill Paxton & The MESA Team
!
!   This program is free software: you can redistribute it and/or modify
!   it under the terms of the GNU Lesser General Public License
!   as published by the Free Software Foundation,
!   either version 3 of the License, or (at your option) any later version.
!
!   This program is distributed in the hope that it will be useful,
!   but WITHOUT ANY WARRANTY; without even the implied warranty of
!   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
!   See the GNU Lesser General Public License for more details.
!
!   You should have received a copy of the GNU Lesser General Public License
!   along with this program. If not, see <https://www.gnu.org/licenses/>.
!
! ***********************************************************************

module run_binary_extras

   use star_lib
   use star_def
   use const_def
   use chem_def
   use num_lib
   use binary_def
   use math_lib

   implicit none

contains

   subroutine extras_binary_controls(binary_id, ierr)
      integer :: binary_id
      integer, intent(out) :: ierr
      type(binary_info), pointer :: b
      ierr = 0

      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if

      ! Set these function pointers to point to the functions you wish to use in
      ! your run_binary_extras. Any which are not set, default to a null_ version
      ! which does nothing.
      b%how_many_extra_binary_history_header_items => how_many_extra_binary_history_header_items
      b%data_for_extra_binary_history_header_items => data_for_extra_binary_history_header_items
      b%how_many_extra_binary_history_columns => how_many_extra_binary_history_columns
      b%data_for_extra_binary_history_columns => data_for_extra_binary_history_columns

      b%extras_binary_startup => extras_binary_startup
      b%extras_binary_start_step => extras_binary_start_step
      b%extras_binary_check_model => extras_binary_check_model
      b%extras_binary_finish_step => extras_binary_finish_step
      b%extras_binary_after_evolve => extras_binary_after_evolve

      ! Once you have set the function pointers you want, then uncomment this (or set it in your star_job inlist)
      ! to disable the printed warning message,
      b%warn_binary_extra = .false.

   end subroutine extras_binary_controls

   integer function how_many_extra_binary_history_header_items(binary_id)
      use binary_def, only: binary_info
      integer, intent(in) :: binary_id
      how_many_extra_binary_history_header_items = 0
   end function how_many_extra_binary_history_header_items

   subroutine data_for_extra_binary_history_header_items( &
      binary_id, n, names, vals, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id, n
      character(len=maxlen_binary_history_column_name) :: names(n)
      real(dp) :: vals(n)
      integer, intent(out) :: ierr
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if
   end subroutine data_for_extra_binary_history_header_items

   integer function how_many_extra_binary_history_columns(binary_id)
      use binary_def, only: binary_info
      integer, intent(in) :: binary_id
      how_many_extra_binary_history_columns = 4
   end function how_many_extra_binary_history_columns

   subroutine data_for_extra_binary_history_columns(binary_id, n, names, vals, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(in) :: n
      character(len=maxlen_binary_history_column_name) :: names(n)
      real(dp) :: vals(n)
      real(dp) :: a_postCE, P_postCE
      integer, intent(out) :: ierr
      ierr = 0
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then
         write (*, *) 'failed in binary_ptr'
         return
      end if

      names(1) = 'tdelay(Gyr)'
      vals(1) = (5d0/256d0) * (clight**5 * b%separation**4) / &
      (standard_cgrav**3 * b%m(1) * b%m(2) * (b%m(1) + b%m(2)))

      ! convert from seconds -> years -> Gyr
      vals(1) = vals(1) / secyer / 1d9

      ! KH rate threshold for CE onset
      names(2) = 'log10(Mdot_KH)'
      vals(2) = log10(b% s_donor% m(1) / Msun / b% s_donor% kh_timescale)

      ! POST-COMMON ENVELOPE period
      ! We will use the energy formalism to compute the post-CE separation a_postCE (in centimeters, for convenience!), and then convert it into the post-CE period P_postCE, in days.
      names(3) = 'P_postCE(days)'
      ! Post-CE orbital separation in cm
      a_postCE = (b% s_donor% he_core_mass * Msun) * b% m(2) / &
         ( (2d0 * b% s_donor% xtra(1)) / standard_cgrav + &
         (b% m(1) * b% m(2)) / b% separation )

      ! Post-CE orbital period in days
      P_postCE = 2d0*pi * sqrt( a_postCE**3 / &
         ( standard_cgrav * (b% s_donor% he_core_mass * Msun + b% m(2)) ) ) / secday
      vals(3) = P_postCE

      ! POST-COMMON ENVELOPE TIME DELAY
      ! The formula is the same that you implemented already before, but this time we will use the post-CE separation (just computed above), the mass of the BH which stays the same, and the mass of the stripped star which is now the core mass.
      names(4) = 'tdelay_postCE(Gyr)'
      vals(4) = (5d0/256d0) * (clight**5 * a_postCE**4) / &
         (standard_cgrav**3 * b% s_donor% he_core_mass * Msun * b%m(2) * (b% s_donor% he_core_mass * Msun + b%m(2)))
      ! convert from seconds -> years -> Gyr
      vals(4) = vals(4) / secyer / 1d9

end subroutine data_for_extra_binary_history_columns

   integer function extras_binary_startup(binary_id, restart, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      logical, intent(in) :: restart
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

!          b% s1% job% warn_run_star_extras = .false.
      extras_binary_startup = keep_going
   end function extras_binary_startup

   integer function extras_binary_start_step(binary_id, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr

      extras_binary_start_step = keep_going
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

   end function extras_binary_start_step

   ! Return either keep_going, retry, or terminate
   integer function extras_binary_check_model(binary_id)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer :: ierr
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if
      extras_binary_check_model = keep_going

   end function extras_binary_check_model

   ! returns either keep_going or terminate.
   ! note: cannot request retry; extras_check_model can do that.
   integer function extras_binary_finish_step(binary_id)
  type(binary_info), pointer :: b
  type (star_info), pointer :: s
  integer, intent(in) :: binary_id
  integer :: ierr
  call binary_ptr(binary_id, b, ierr)
  if (ierr /= 0) then  ! failure in  binary_ptr
      return
  end if
  extras_binary_finish_step = keep_going

  if (abs(b% mtransfer_rate)*secyer/Msun > 10d0*b% s_donor% m(1) /Msun / b% s_donor% kh_timescale) then
      extras_binary_finish_step = terminate
      write(*,*) "Terminate due to mdot>10*M_kh: CE onset!"
  end if

  end function extras_binary_finish_step

   subroutine extras_binary_after_evolve(binary_id, ierr)
      type(binary_info), pointer :: b
      integer, intent(in) :: binary_id
      integer, intent(out) :: ierr
      call binary_ptr(binary_id, b, ierr)
      if (ierr /= 0) then  ! failure in  binary_ptr
         return
      end if

   end subroutine extras_binary_after_evolve

end module run_binary_extras
